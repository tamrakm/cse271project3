/**
 * This class holds the information needed for BigEnemy
 * @author Mihir Tamrakar
 * Date: 4/4/2022
 *
 */
public class BigEnemy extends Enemy {
	//=============================================Methods=============	
	/**
	 * The default constructor that initializes instance properties.
	 */
	public BigEnemy() {
		super(flags, flags, flags, flags, enemySpeed);
	}
	//{@inheritDoc}
	@Override
	public void setColor() {

	}
	//{@inheritDoc}
	@Override
	public void move(int width, int height) {

	}
	//{@inheritDoc}
	@Override
	public void processCollision(ArrayList<Enemy> list, int enemy) {

	}
}