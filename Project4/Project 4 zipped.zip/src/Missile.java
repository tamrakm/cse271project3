import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JComponent;

/**
 * This class holds the information needed for Missile
 * @author Mihir Tamrakar
 * Date: 4/4/2022
 *
 */
public class Missile extends JComponent {
	//=============================================Instance Properties=============
	private int missileSpeed;
	private Color missileColor;
//=============================================Methods=============	
	/**
	 * The default constructor that initializes instance properties.
	 */
	public Missile() {
		this.missileSpeed = 0;
		this.missileColor = null;
	}
	/**
	 * This method paints the missile
	 * @param g is Graphics
	 */
	@Override
	public void paintComponent(Graphics g) {
		
	}
	
	/**
	 * This method determines the next position on the screen the Missile 
	 * should appear on after being repainted. If the missile is off the 
	 * screen the method removes it from the ArrayList. 
	 * @param width
	 * @param height
	 * @param list
	 * @param missile
	 */
	public void move(int width, int height, ArrayList<Missile> list, 
			int missile) {
		
	}
}
