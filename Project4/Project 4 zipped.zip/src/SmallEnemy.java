import java.util.ArrayList;

/**
 * This class holds the information needed for SmallEnemy
 * @author Mihir Tamrakar
 * Date: 4/4/2022
 *
 */
public class SmallEnemy extends Enemy {
	//=============================================Methods=============	
	/**
	 * The default constructor that initializes instance properties.
	 */
	public SmallEnemy() {
		super(flags, flags, flags, flags, enemySpeed);
	}
	//{@inheritDoc}
	@Override
	public void setColor() {

	}
	//{@inheritDoc}
	@Override
	public void move(int width, int height) {

	}

	//{@inheritDoc}
	@Override
	public void processCollision(ArrayList<Enemy> list, int enemy) {
		// TODO Auto-generated method stub

	}
}
