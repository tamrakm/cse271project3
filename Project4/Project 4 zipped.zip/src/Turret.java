import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.JComponent;

/**
 * This class holds the information needed for Turret
 * @author Mihir Tamrakar
 * Date: 4/4/2022
 *
 */
public class Turret extends JComponent {
	//=============================================Instance Properties=============
		private Rectangle base;
		private Rectangle turret;
		private Color turrentColor;
	//=============================================Methods=============	
		/**
		 * The default constructor that initializes instance properties.
		 */
		public Turret() {
			this.base = null;
			this.turret = null;
			this.turrentColor = null;
		}
		
		/**
		 * This method paints the Turret base and Turret barrel.
		 * @param g is Graphics
		 */
		@Override
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.setColor(Color.black); 
			g.fillRect(500, 600, this.getWidth(), this.getHeight());
		}
}
